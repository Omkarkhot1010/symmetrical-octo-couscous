package com.cjc.crud.webapp.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cjc.crud.webapp.dao.HomeDao;
import com.cjc.crud.webapp.model.Student;

import jakarta.persistence.Query;

@Repository
public class HomeDaoimp implements HomeDao 
{

	@Autowired
	SessionFactory sf;

	@Override
	public void saveData(Student s) 
	{
		Session session=sf.openSession();
		session.save(s);
		session.beginTransaction().commit();

	}

	@Override
	public List<Student> logincheck(String un, String ps) 
	{
		Session session=sf.openSession();
		if (un.equalsIgnoreCase("Admin")&& ps.equalsIgnoreCase("Admin")) 
		{
			List<Student> ls=session.createQuery("from Student").getResultList();
			return ls;
		}
		else 
		{
			Query query=session.createQuery("from Student where uname=?1 and password=?2");
			query.setParameter(1, un);
			query.setParameter(2, ps);
			List<Student> ls=query.getResultList();
            return ls;
		}


	}

	@Override
	public List<Student> deleteData(int uid) 
	{      
		Session session=sf.openSession();
		Query query=session.createQuery("delete from Student Where uid=?1");
		query.setParameter(1, uid);
		Transaction tx=session.beginTransaction();
		query.executeUpdate();
		tx.commit();
		
		List<Student> ls=session.createQuery("from Student").getResultList();
		return ls;
	
	}

}
