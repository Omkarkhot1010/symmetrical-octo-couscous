package com.cjc.crud.webapp.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.crud.webapp.dao.HomeDao;
import com.cjc.crud.webapp.model.Student;
import com.cjc.crud.webapp.service.HomeService;

@Service
public class HomeServiceImpl implements HomeService{

	@Autowired
	HomeDao hd;
	
	
	@Override
	public void saveData(Student s) 
	{
		hd.saveData(s);
		
	}


	@Override
	public List<Student> logincheck(String un, String ps) {
		
		return hd.logincheck(un,ps);
	}


	@Override
	public List<Student> deleteData(int uid) 
	{
		
		return hd.deleteData(uid);
	}

}
