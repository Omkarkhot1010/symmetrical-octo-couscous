package com.cjc.crud.webapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cjc.crud.webapp.model.Student;
import com.cjc.crud.webapp.service.HomeService;

@Controller
public class HomeController 
{
	
	
	@Autowired
	HomeService hs;

	@RequestMapping("/")
	public String preLogin()
	{
		return "login";
	}
	
	@RequestMapping("/registration")
	public String preReg()
	{
		return "registration";
	}
	
	@RequestMapping("/reg")
	public String regData(@ModelAttribute Student s)
	{
		hs.saveData(s);
		return "login";
	}
	
	@RequestMapping("/login")
	public String loginCheck(@RequestParam("uname") String un,@RequestParam("password") String ps,Model m)
	{
		List<Student> list=hs.logincheck(un,ps);
		m.addAttribute("data", list);
		return "success";
		
	}
	
	@RequestMapping("/delete")
	public String deleteData(@RequestParam("uid") int uid,Model m)
	{
		List<Student> list=hs.deleteData(uid);
		m.addAttribute("data", list);
		
		return "success";
	}
	
	
	
}
