package com.cjc.crud.webapp.dao;

import java.util.List;

import com.cjc.crud.webapp.model.Student;

public interface HomeDao 
{

	public void saveData(Student s);
	public List<Student> logincheck(String un,String ps);
	public List<Student> deleteData(int uid);
}
